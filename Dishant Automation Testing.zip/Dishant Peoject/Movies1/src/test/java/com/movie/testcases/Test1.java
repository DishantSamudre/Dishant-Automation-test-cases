package com.movie.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.movies.base.Baseclass;
import com.pagemovie.base.Homepage;

	
	 public class Test1 extends Baseclass{
		 
		 Homepage page;
			
			public Test1() {
				super();   
			 
			}
			
			@BeforeMethod
			public void Setup() throws Exception
			{
				initialization();
				page=new Homepage();
				
			}
			@Test(priority=1)
			public void Table() throws Exception 
			{
				page.printSearchItem();
			}
			
			@Test(priority=2)
			public void ClickMovieLinkTest()
			{
				page.ClickMovieLink();
			}
			
			@Test(priority=3)
			public void verifyGenreRatingTest()
			{
				page.ClickMovieLink();
			    page.verifyGenreRating();
			}
			
			@Test(priority=4)
			public void verifyDirectorNameTest()
			{
				page.ClickMovieLink();
				String DirectorName=page.verifyDirectorName();
				Assert.assertEquals(DirectorName, "Francis Ford Coppola");
				System.out.println("Director Name Verified");
			}
			
			@Test(priority=5)
			public void verifyCharecterNameTest()
			{
		page.ClickMovieLink();
				page.verifyDirectorName();
				page.verifyCharecterName();
				
			}
			@AfterMethod
			public void tearDown()
			{
				driver.close();
			}
			



		}

		    
	 

	    