package com.pagemovie.base;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.movies.base.Baseclass;

public class Homepage extends Baseclass {

	
	public Homepage()
	{
		PageFactory.initElements(driver, this);
	}
	
	 
	
	@FindBy(xpath="//div[@class=\"content-container\"]//div")
	List<WebElement> SearchResult;
		
	public void printSearchItem()throws Exception
	{				
		for(WebElement link:SearchResult)
		{
		System.out.println(link.getText());//prints all Search Results
		}
	}

	 

@FindBy(xpath="(//a[contains(text(),\"The Godfather\")])[1]")WebElement link1972;

public void ClickMovieLink()
{
	link1972.click();
}

 

@FindBy(xpath="//span[@class=\"header-movie-genres\"]")WebElement genre;

@FindBy(xpath="//span[text()=\"R\"]")WebElement rating;

public void verifyGenreRating()
{
	String ActualGenre= genre.getText();
	String ExpGenre="Crime";
	String Actrating=rating.getText();
	String Exprating="A";
	if(ActualGenre.contains(ExpGenre)&& Actrating.equals(Exprating))
	{
		System.out.println("Test case Pass "+ActualGenre+" MPAA rating= "+Actrating);
	}
	else
	{
		System.out.println("Test case Failed "+ActualGenre+" MPAA rating= "+Actrating);
	}
}

 

@FindBy(xpath="//a[@title=\"Cast & Crew\"]")WebElement castlink;

@FindBy(xpath="(//a[text()=\"Francis Ford Coppola\"])[2]")WebElement Directorname;

public String verifyDirectorName()
{
	castlink.click();
	return Directorname.getText();
}


@FindBy(xpath="(//a[text()=\"Al Pacino\"])[1]")WebElement heroname;

@FindBy(xpath="(//div[@class=\"cast_role\"])[2]")WebElement charectername;

public void verifyCharecterName()
{
	String HeroName=heroname.getText();
	String CharName=charectername.getText();
	if(HeroName==CharName)
	{
		System.out.println("Character Name Verified");
	}
	else
	{
		System.out.println("Charecter name not verified");
	}
}
}

	

