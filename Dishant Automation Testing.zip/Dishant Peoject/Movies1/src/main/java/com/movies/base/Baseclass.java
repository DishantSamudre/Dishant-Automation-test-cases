package com.movies.base;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Baseclass {

public static  WebDriver driver;
	
	 
public static void initialization() throws InterruptedException {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\User\\Desktop\\chromedriver.exe");
	  driver = new ChromeDriver(); 
	 
	 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	 driver.manage().window().maximize();
		 driver.get("http://www.allmovie.com");
		 
		 driver.findElement(By.xpath("//input[@type=\"search\"]")).sendKeys("The Godfather");
			Thread.sleep(2000);
		driver.findElement(By.linkText("See All Results for \"the godfather\"")).click();
		Thread.sleep(2000);
		 
	}
}

