package com.table.page;

 

import java.util.List;
 
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.table.base.Base;

public class Page extends Base {
	
	public Page()
	{
		PageFactory.initElements(driver, this);
	}
	
@FindBy(xpath="//select[@name=\"example_length\"]") WebElement N;

public void drop() {
	
	Select s= new Select(N);
	s.selectByVisibleText("25");
}


@FindBy(xpath="//th[@aria-sort=\"ascending\"]")WebElement A;
@FindBy(xpath="//table[@id=\"example\"]")List<WebElement> T;


@SuppressWarnings("unlikely-arg-type")
public void Table1()throws Exception
{

 
	for(WebElement link:T)
	{
	System.out.println(link.getText()); 
	if(link.equals("Yuri Berry") ){
		break;
	}
	}
}

	

@FindBy(xpath="(//tr[@class=\"even\"])[4]")WebElement s;

 

@FindBy(xpath="(//tr[@class=\"odd\"])[7]")WebElement s2;
 
 
 

public void age(){
	
	A.click();
	
	
}

public void  software1() {

	
	 System.out.println("Software engg1 "+s.getText());
	 
}
public void  software2() {
	
	 System.out.println("Software engg 2"+s2.getText());
	 
	 
}
	


}
