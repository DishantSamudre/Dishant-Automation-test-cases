package com.table.test;

 
 
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.table.base.Base;
import com.table.page.Page;

public class Test1 extends Base {

	Page Table;
		
		public Test1() {
			
			super();   
		 
		}
	
		@BeforeMethod
		public void Setup() throws Exception
		{
			initialization();
			Table=new Page();
			
		}
		
		@Test(priority=1)
		public void drop() throws Exception 
		{
			Table.drop();
		}
		
		@Test(priority=2)
		public void age()
		{
			Table.age();
		}
		
		@Test(priority=3)
		public void Table1() throws Exception
		{
			Table.drop();
			Table.age();
			Table.Table1();
			 
		}
		
		@Test(priority=4)
		public void software1() throws InterruptedException
		{
			Thread.sleep(2000);
			Table.drop();
			Thread.sleep(2000);
			Table.age();
			Thread.sleep(2000);
			Table.software1();
			 
		}
		
		@Test(priority=5)
		public void software2() throws InterruptedException
		{
			Table.drop();
			Thread.sleep(2000);
			Table.age();
			Thread.sleep(2000);
			Table.software2();
			 
			
		}
		@AfterMethod
		public void tearDown()
		{
			driver.close();
		}
		


	
}
