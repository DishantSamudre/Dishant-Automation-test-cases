package page1;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.flipkart.base.Base1;

public class hpage1 extends Base1{
		Actions act = new Actions(driver);
		
		public hpage1()
		{
			PageFactory.initElements(driver,this);
		}

		@FindBy(xpath="//img[@alt='Mobiles']")WebElement k;

		@FindBy(xpath="(//span[@class=\"_2I9KP_\"])[1]")WebElement e;

		@FindBy(xpath="//a[@title='Mi']")WebElement m;

		public void MobileClick() throws InterruptedException
		{
			k.click();
		    Actions act = new Actions(driver);
		    act.moveToElement(e).build().perform();
		    Thread.sleep(2000);
		    act.moveToElement(m).click().build().perform();
		    Thread.sleep(2000);
		}

		 
		@FindBy(xpath="//div[@class=\"_31Kbhn WC_zGJ\"]")WebElement S;
		@FindBy(xpath="//div[@class=\"_2IN3-t _1mRwrD\"]")WebElement T;

		public void ChangePrice()
		{
			Actions act = new Actions(driver);
			act.clickAndHold(S).moveToElement(T).release().build().perform();
		}

		 
		@FindBy(xpath="//div[@class='_3uDYxP']//select[@class='_2YxCDZ']")WebElement ma;

		public void Select3Max() 
		{
			Select s=new Select(m);
			s.selectByValue("7000");
		}
		@FindBy(xpath="//input[@placeholder='Search for products, brands and more']")WebElement st;

		@FindBy(xpath="//button[@type=\"submit\"]")WebElement s;

		public void SerachRedmi() throws InterruptedException
		{
			st.sendKeys("redmi go (black, 8 gb)");
			Thread.sleep(2000);
			s.click();
			Thread.sleep(2000);
		}
		 
		@FindBy(xpath="//div[normalize-space()='Redmi Go (Black, 8 GB)']")WebElement P;

		@FindBy(xpath="//div[@data-id='MOBFDZQHCJFYXZHX']//div[@class='_25b18c']//div[1]")WebElement A;
		public void verifyProductAmt()
		{
			P.click();
			String s=A.getText();
			try
			{
				int amount=Integer.parseInt(s);  
				if(amount>=0)
				{
					A.click();
				}
			}
			catch(NumberFormatException e)
			{
				
			}
		}



				
				
		

}
