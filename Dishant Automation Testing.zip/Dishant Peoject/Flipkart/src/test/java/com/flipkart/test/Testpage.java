package com.flipkart.test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.flipkart.base.Base1;

import page1.hpage1;

 

	
	public class Testpage extends Base1 {
		hpage1 p;
		public Testpage()
		{
			super();
		}
		
		@BeforeMethod
		public void Setup() throws Exception
		{
			initialization();
			p=new hpage1();
		}
		
		@Test(priority=1,groups="Sanity")
		public void MobileClickTest() throws InterruptedException
		{
			p.MobileClick();
			Thread.sleep(2000);
		}
		@Test(priority=2,groups="Sanity")
		public void ChangePriceTest() throws InterruptedException
		{
			p.MobileClick();
			Thread.sleep(2000);
			p.ChangePrice();
			Thread.sleep(2000);
		}
		@Test(priority=1,groups="Sanity")
		public void Select3MaxTest() throws InterruptedException
		{
			p.MobileClick();
			Thread.sleep(2000);
			p.Select3Max();
			Thread.sleep(2000);
			
		}
		@Test(priority=1,groups="Rgression")
		public void SearchRedmiTest() throws InterruptedException
		{
			p.SerachRedmi();
		}
		@Test(priority=1,groups="Rgression")
		public void VerifyProductAmtTest() throws InterruptedException
		{
			p.SerachRedmi();
			p.verifyProductAmt();
		}
		
		
		
	@AfterMethod
		public void tearDown()
		{
			driver.close();
		}


	
	}	
		 