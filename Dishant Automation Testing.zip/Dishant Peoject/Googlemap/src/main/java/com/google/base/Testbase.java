package com.google.base;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Testbase {
	
public static WebDriver driver;
	
	 
	public static void initialization() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\User\\Desktop\\chromedriver.exe");
		  driver = new ChromeDriver(); 
		 
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 driver.manage().window().maximize();
		 driver.get("https://www.google.com/maps");
		 
	}
	
	 
		   
		public void TakeScreenShot() throws Exception{
		    TakesScreenshot scrShot =((TakesScreenshot)driver);
		    File S=scrShot.getScreenshotAs(OutputType.FILE);
		    File D=new File("C:\\Users\\User\\Desktop\\ScreenShot/"
		    		+ "Google.jpg");
		    FileUtils.copyFile(S, D);
		}


}
